package com.zorba;

import org.w3c.dom.ls.LSOutput;

public class StringPractice {

   public static void main(String [] args) {
       String myString = " Hello World";
       int myStringLength = myString.length();
       System.out.println(myStringLength);
       String UpperCase = myString.toUpperCase();
       System.out.println(UpperCase);

   }
}

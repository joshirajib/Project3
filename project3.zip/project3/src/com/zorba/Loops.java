package com.zorba;

public class Loops {

    public static void loopPractice() {

        int a = 0;
        while (a < 10) {
            System.out.println("The value of a is: " + a);
            a++;
        }

    }
    public static void main(String []  args){

       Loops.loopPractice();

    }
}
